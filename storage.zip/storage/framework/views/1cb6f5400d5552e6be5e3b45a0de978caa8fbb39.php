<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cetak Struk</title>
    <style>
        body {
            width: 75mm;
            margin: 0;
            font-family: 'Courier New', Courier, monospace;
            font-size: 10px;
            color: black;
            /* Pastikan cetakan hanya black & white */
        }

        .container {
            text-align: center;
        }

        h1 {
            font-size: 16px;
            margin-bottom: 5px;
        }

        p {
            margin: 5px 0;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 10px;
        }

        th,
        td {
            border: 1px solid black;
            padding: 5px;
        }

        th {
            text-align: left;
        }

        td {
            text-align: left;
        }

        td:last-child {
            text-align: right;
            /* Kolom terakhir (Total) rata kanan */
        }

        .total {
            text-align: right;
            font-weight: bold;
            margin-top: 10px;
        }

        footer {
            text-align: center;
            margin-top: 20px;
            font-size: 10px;
        }

        /* Sembunyikan tombol cetak saat mencetak */
        @media print {
            .btn-print {
                display: none;
            }

        }
    </style>
</head>

<body>
    <div class="container">
        <!-- Logo -->
        <img src="<?php echo e(asset('assets/img/CleanLaundryLogo.png')); ?>" alt="Clean Laundry" width="100">

        <!-- Informasi Toko -->
        <h1>Clean Laundry</h1>
        <p>Jl. Istiqomah RT01/RW08 No. 41</p>
        <p>Kelurahan Cipadu, Kecamatan Larangan</p>
        <p>Kota Tangerang, Banten</p>

        <!-- Tabel Transaksi -->
        <table>
            <thead>
                <tr>
                    <th>Layanan</th>
                    <th>Harga</th>
                    <th>Qty</th>
                    <th>Total</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $transaction->details; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $detail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($detail->service->service_name); ?></td>
                    <td>Rp <?php echo e(number_format($detail->price, 0, ',', '.')); ?></td>
                    <td><?php echo e($detail->quantity.$detail->service->unit); ?></td>
                    <td>Rp <?php echo e(number_format($detail->price * $detail->quantity, 0, ',', '.')); ?></td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>

        <!-- Total Harga -->
        <div class="total">
            Total Harga: Rp <?php echo e(number_format($transaction->details->sum(fn($d) => $d->price * $d->quantity), 0, ',', '.')); ?>

        </div>

        <!-- Tombol Cetak -->
        <button class="btn-print" onclick="window.print()">Cetak Struk</button>
    </div>

    <!-- Footer Ucapan Terima Kasih -->
    <footer>
        <p>Terima kasih sudah memakai jasa Clean Laundry.</p>
        <p>Semoga Anda puas dengan layanan kami!</p>
    </footer>
</body>

</html><?php /**PATH D:\Data\Felix\Unpam\Semester 6\KERJA PRAKTEK\code\resources\views/transaksi/print.blade.php ENDPATH**/ ?>