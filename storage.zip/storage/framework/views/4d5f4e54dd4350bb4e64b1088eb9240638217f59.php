
<?php $__env->startSection('content'); ?>
<?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<!-- Content di sini -->
<main class="app-main">
    <div class="app-content">
        <div class="container-fluid">
            <div class="mt-5">
                <div class="card-body">
                    <div class="d-flex justify-content-between align-items-center mb-4 search-actions-container">
                        <?php if(in_array($roleName, ['admin'])): ?>
                        <a href="<?php echo e(route('pengguna.create')); ?>" class="button--primary">Tambah Pengguna</a>
                        <?php endif; ?>
                        <form action="<?php echo e(route('pengguna')); ?>" method="GET" id="searchForm" class="search-container">
                            <input type="text" name="search" class="form-control" placeholder="Search" aria-label="Search" value="<?php echo e($search); ?>" oninput="delayedSearch()">
                        </form>
                    </div>
                    <table class="table table-bordered">
                        <thead>
                            <tr>
                                <th>Nama</th>
                                <th>Username</th>
                                <th>Peran</th>
                                <th>Nomor Telepon</th>
                                <th>Aksi</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__empty_1 = true; $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr class="align-middle">
                                <td><?php echo e($user->name); ?></td>
                                <td><?php echo e($user->username); ?></td>
                                <td><?php echo e($user->role->role_name ?? 'N/A'); ?></td>
                                <td><?php echo e($user->phone_number); ?></td>
                                <td>
                                    <div class="icon-actions">
                                        <?php if(in_array($roleName, ['admin'])): ?>
                                        <a href="<?php echo e(route('pengguna.edit', $user->id)); ?>" class="btn btn-sm"><img src="<?php echo e(asset('assets/img/Edit.svg')); ?>" alt="Edit" width="60%" height="60%"></a>
                                        <!-- Tombol Delete -->
                                        <button class="btn btn-sm" onclick="confirmAction('<?php echo e($user->id); ?>', 'Apakah kamu yakin ingin menghapus data ini?', '/pengguna/<?php echo e($user->id); ?>', 'DELETE', 'Hapus')">
                                            <img src="<?php echo e(asset('assets/img/Trash.svg')); ?>" alt="Hapus" width="60%" height="60%">
                                        </button>

                                        <!-- Tombol Reset Password -->
                                        <button class="btn btn-sm" onclick="confirmAction('<?php echo e($user->id); ?>', 'Apakah kamu yakin ingin mereset password pengguna ini?', '/pengguna/reset-password/<?php echo e($user->id); ?>', 'POST', 'Reset Password')">
                                            <img src="<?php echo e(asset('assets/img/Synchronize.svg')); ?>" alt="Reset Password" width="60%" height="60%">
                                        </button>
                                        <?php endif; ?>
                                    </div>
                                    <div class="action-menu">
                                        <button class="btn btn-sm" data-bs-toggle="dropdown" aria-expanded="false">
                                            <i class="bi bi-three-dots-vertical"></i>
                                        </button>
                                        <ul class="dropdown-menu">
                                            <?php if(in_array($roleName, ['admin'])): ?>
                                            <li><a class="dropdown-item" href="<?php echo e(route('layanan.edit', $user->id)); ?>">Ubah</a></li>
                                            <li>
                                                <button type="submit" class="dropdown-item" onclick="confirmDelete('<?php echo e($user->id); ?>')">Hapus</button>
                                            </li>
                                            <li>
                                                <button type="submit" class="dropdown-item" onclick="confirmReset('<?php echo e($user->id); ?>')">Reset Passwprd</button>
                                            </li>
                                            <?php endif; ?>
                                        </ul>
                                    </div>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td colspan="4" class="text-center">Tidak ada data pengguna</td>
                            </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>

                    <!-- Pagination -->
                    <div class="card-footer clearfix pagination--container">
                        <?php echo e($users->links('pagination::bootstrap-4')); ?>

                    </div>
                </div>
            </div>
        </div>
    </div>
</main>

<div class="modal fade" id="confirmActionModal" tabindex="-1" aria-labelledby="confirmActionLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="confirmActionLabel">Konfirmasi</h5>
            </div>
            <div class="modal-body" id="confirmActionMessage">
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-primary" data-dismiss="modal">Batal</button>
                <form id="actionForm" method="POST">
                    <?php echo csrf_field(); ?>
                    <input type="hidden" name="_method" id="actionMethod" value="DELETE">
                    <button type="submit" class="btn btn-danger" id="confirmButtonText">

                    </button>
                </form>
            </div>
        </div>
    </div>
</div>

<script>
 let searchTimeout;
    function confirmAction(id, message, actionUrl, method = 'DELETE', buttonText = 'Hapus') {
        document.getElementById('confirmActionMessage').textContent = message;
        const actionForm = document.getElementById('actionForm');
        actionForm.action = actionUrl;
        document.getElementById('actionMethod').value = method;
        document.getElementById('confirmButtonText').textContent = buttonText;
        const modal = new bootstrap.Modal(document.getElementById('confirmActionModal'));
        modal.show();
    }

    function delayedSearch() {
        clearTimeout(searchTimeout);
        searchTimeout = setTimeout(() => {
            document.getElementById('searchForm').submit();
        }, 2000);
    }
</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/cleanla1/public_html/resources/views/pengguna/index.blade.php ENDPATH**/ ?>