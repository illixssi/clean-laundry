<form action="<?php echo e(isset($user) ? route('pengguna.update', $user->id) : route('pengguna.store')); ?>" method="POST">
    <?php echo csrf_field(); ?>
    <?php if(isset($user)): ?>
    <?php echo method_field('POST'); ?>
    <?php endif; ?>

    <div class="mb-3 row align-items-center">
        <label for="name" class="col-sm-4 col-form-label fw-semibold">Nama</label>
        <div class="col-sm-8">
            <input type="text" class="form-control" id="name" name="name" value="<?php echo e($user->name ?? ''); ?>" placeholder="Nama" required>
        </div>
    </div>

    <div class="mb-3 row align-items-center">
        <label for="username" class="col-sm-4 col-form-label fw-semibold">Username</label>
        <div class="col-sm-8">
            <input type="text" class="form-control" id="username" name="username" value="<?php echo e($user->username ?? ''); ?>" placeholder="Username" required>
        </div>
    </div>

    <div class="mb-3 row align-items-center">
        <label for="role_id" class="col-sm-4 col-form-label fw-semibold">Peran</label>
        <div class="col-sm-8">
            <select class="form-select" id="role_id" name="role_id" required>
                <option value="">Pilih Peran</option>
                <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($role->id); ?>" <?php echo e((isset($user) && $user->role_id == $role->id) ? 'selected' : ''); ?>>
                    <?php echo e($role->role_name); ?>

                </option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
    </div>

    <div class="mb-3 row align-items-center">
        <label for="phone_number" class="col-sm-4 col-form-label fw-semibold">Nomor Telepon</label>
        <div class="col-sm-8">
            <input type="tel" class="form-control" id="phone_number" name="phone_number" value="<?php echo e($user->phone_number ?? ''); ?>" placeholder="Nomor Telepon" required>
        </div>
    </div>

    <div class="d-flex justify-content-end mt-4">
        <a href="<?php echo e(route('pengguna')); ?>" class="btn btn-danger me-3" style="width: 100px;">Batal</a>
        <button type="submit" class="btn btn-primary" style="width: 100px;"><?php echo e(isset($user) ? 'Update' : 'Submit'); ?></button>
    </div>
</form><?php /**PATH /home/cleanla1/public_html/resources/views/pengguna/form.blade.php ENDPATH**/ ?>