

<?php $__env->startSection('content'); ?>
<!-- Memanggil Header -->
<?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<!-- Memanggil Sidebar -->
<?php echo $__env->make('layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<!-- Content di sini -->
<main class="app-main">
    <div class="app-content">
        <div class="container-fluid">
            <div class="mt-5">
                <div class="card-body">
                    <div class="d-flex justify-content-between align-items-center mb-4 search-actions-container">
                        <?php if(in_array($roleName, ['admin', 'kepala_operasional', 'kasir'])): ?>
                        <a href="<?php echo e(route('transaksi.create')); ?>" class="button--primary">Tambah Transaksi</a>
                        <?php endif; ?>
                        <!-- Form Pencarian -->
                        <form action="<?php echo e(route('transaksi')); ?>" method="GET" id="searchForm" class="search-container">
                            <input type="text" name="search" class="form-control" placeholder="Search" aria-label="Search" value="<?php echo e($search); ?>" oninput="delayedSearch()">
                        </form>
                    </div>

                    <!-- Tabel Data Transaksi -->
                    <table class="table table-bordered">
                        <thead>
                            <tr>
                                <th>Nomor Order</th>
                                <th>Nama Pelanggan</th>
                                <th>Tanggal Pesanan Dibuat</th>
                                <th>Total Harga</th>
                                <th>Status</th>
                                <th>Aksi</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__empty_1 = true; $__currentLoopData = $transactions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $transaction): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr class="align-middle">
                                <td><?php echo e($transaction->order_number); ?></td>
                                <td><?php echo e($transaction->customer->name ?? 'N/A'); ?></td>
                                <td><?php echo e($transaction->created_at ? $transaction->created_at->format('d/m/Y - H:i') : 'N/A'); ?></td>
                                <td>Rp <?php echo e(number_format($transaction->total_price, 0, ',', '.')); ?></td>
                                <td><?php echo e($transaction->status); ?></td>
                                <td>
                                    <div class="icon-actions">
                                        <a href="<?php echo e(route('transaksi.view', $transaction->id)); ?>" class="btn btn-sm"><img src="<?php echo e(asset('assets/img/Eye.svg')); ?>" alt="Lihat" width="60%" height="60%"></a>
                                        <?php if(in_array($roleName, ['admin', 'kepala_operasional'])): ?>
                                        <a href="<?php echo e(route('transaksi.edit', $transaction->id)); ?>" class="btn btn-sm"><img src="<?php echo e(asset('assets/img/Edit.svg')); ?>" alt="Edit" width="60%" height="60%"></a>
                                        <button class="btn btn-sm" onclick="confirmDelete('<?php echo e($transaction->id); ?>')">
                                            <img src="<?php echo e(asset('assets/img/Trash.svg')); ?>" alt="Hapus" width="60%" height="60%">
                                        </button>
                                        <?php endif; ?>
                                    </div>
                                    <div class="action-menu">
                                        <button class="btn btn-sm" data-bs-toggle="dropdown" aria-expanded="false">
                                            <i class="bi bi-three-dots-vertical"></i>
                                        </button>
                                        <ul class="dropdown-menu">
                                            <li><a class="dropdown-item" href="<?php echo e(route('transaksi.view', $transaction->id)); ?>">Lihat</a></li>
                                            <?php if(in_array($roleName, ['admin', 'kepala_operasional'])): ?>
                                            <li><a class="dropdown-item" href="<?php echo e(route('transaksi.edit', $transaction->id)); ?>">Ubah</a></li>
                                            <li>
                                                <button type="submit" class="dropdown-item" onclick="confirmDelete('<?php echo e($transaction->id); ?>')">Hapus</button>
                                            </li>
                                            <?php endif; ?>
                                        </ul>
                                    </div>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td colspan="6" class="text-center">Tidak ada data transaksi</td>
                            </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>

                    <!-- Pagination -->
                    <div class="card-footer clearfix pagination--container">
                        <?php echo e($transactions->links('pagination::bootstrap-4')); ?>

                    </div>
                </div>
            </div>
        </div>
    </div>
</main>

<script>
    let searchTimeout;

    function delayedSearch() {
        // Clear timeout sebelumnya jika ada
        clearTimeout(searchTimeout);

        // Set timeout baru untuk delay 2 detik
        searchTimeout = setTimeout(() => {
            document.getElementById('searchForm').submit();
        }, 2000); // 2000 ms = 2 detik
    }
</script>

<div class="modal fade" id="confirmDeleteModal" tabindex="-1" aria-labelledby="confirmDeleteLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="confirmDeleteLabel">Konfirmasi</h5>
            </div>
            <div class="modal-body">
                Apakah kamu yakin ingin menghapus data ini?
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-primary" data-dismiss="modal">Batal</button>
                <form id="deleteForm" method="POST">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('DELETE'); ?>
                    <button type="submit" class="btn btn-danger">Hapus</button>
                </form>
            </div>
        </div>
    </div>
</div>

<script>
    function confirmDelete(id) {
        const deleteForm = document.getElementById('deleteForm');
        deleteForm.action = `/transaksi/${id}`;
        const modal = new bootstrap.Modal(document.getElementById('confirmDeleteModal'));
        modal.show();
    }

    function delayedSearch() {
        clearTimeout(searchTimeout);
        searchTimeout = setTimeout(() => {
            document.getElementById('searchForm').submit();
        }, 2000);
    }
</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/cleanla1/public_html/resources/views/transaksi/index.blade.php ENDPATH**/ ?>