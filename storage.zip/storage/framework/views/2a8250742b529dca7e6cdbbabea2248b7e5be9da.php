
<?php $__env->startSection('content'); ?>
<?php echo $__env->make('layouts.header', ['showButtons' => false], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<main class="app-main">
    <div class="app-content">
        <h3 class="mb-4 mt-4 ms-4 fw-bold">Detil Transaksi</h3>
        <div class="container-fluid">
            <div class="mt-5 d-flex justify-content-center">
                <div class="p-4 form--container d-flex justify-content-between" style="max-width: 70%; width: 100%;">
                    <!-- Transaction Details -->
                    <div class="transaction-details">
                        <div class="detail-row">
                            <div class="detail-label">Nama Pelanggan</div>
                            <div class="detail-value"><?php echo e($transaction->customer->name ?? '-'); ?></div>
                        </div>
                        <div class="detail-row">
                            <div class="detail-label">Kontak</div>
                            <div class="detail-value">
                                <p><?php echo e($transaction->customer->phone_number ?? '-'); ?></p>
                                <p><?php echo e($transaction->customer->address ?? '-'); ?></p>
                            </div>
                        </div>
                        <div class="detail-row">
                            <div class="detail-label">Jumlah Pakaian</div>
                            <div class="detail-value">
                                <?php echo e($transaction->clothes_quantity ?? '-'); ?> pcs
                            </div>
                        </div>
                        <div class="detail-row">
                            <div class="detail-label">Status</div>
                            <div id="status-section">
                                <div class="status-box disabled--style" id="status-display">
                                    <?php echo e($transaction->status ?? 'Null'); ?>

                                </div>
                                <select id="status-dropdown" class="form-select" style="display: none;">
                                    <?php
                                    $statuses = explode(',', env('STATUS_OPTIONS', 'ERROR'));
                                    ?>
                                    <?php $__currentLoopData = $statuses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $status): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($status); ?>" <?php echo e($transaction->status === $status ? 'selected' : ''); ?>>
                                        <?php echo e($status); ?>

                                    </option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                        </div>
                    </div>

                    <div class="mid--section d-flex align-items-end">
                        <?php if(in_array($roleName, ['admin', 'kepala_operasional', 'kasir', 'staf_laundry'])): ?>
                        <button type="button" class="btn btn-primary me-2" id="edit-status-button"
                            onclick="enableStatusEdit()">Ubah Status</button>
                        <button type="button" class="btn btn-secondary me-2" id="back-status-button" style="display: none;" onclick="normal()">Kembali</button>
                        <form id="updateForm" method="POST" action="<?php echo e(route('transaksi.updateStatus', $transaction->id)); ?>" class="status--form--container">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('POST'); ?>
                            <input type="hidden" name="status" id="status-hidden"> <!-- Pastikan elemen ini ada -->
                            <button type="button" class="btn btn-primary" id="ok-status-button" style="display: none;" onclick="submitForm()">Simpan</button>
                        </form>
                        <?php endif; ?>
                    </div>

                    <!-- Right-Side Section -->
                    <div class="right-section">
                        <div class="notes--container">
                            <label for="notes" class="form-label">Catatan</label>
                            <textarea class="form-control disabled--style" rows="4" disabled><?php echo e($transaction->notes ?? ''); ?></textarea>
                        </div>
                    </div>
                </div>
            </div>

            <div class="d-flex justify-content-center mt-4">
                <table class="table table-bordered text-center" style="max-width: 80%;">
                    <thead>
                        <tr>
                            <th>Layanan</th>
                            <th>Kuantitas/Satuan</th>
                            <th>Harga</th>
                        </tr>
                    </thead>
                    <tbody id="serviceTableBody">
                        <?php if(isset($transaction->details) && $transaction->details->isNotEmpty()): ?>
                        <?php $__currentLoopData = $transaction->details; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $detail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr data-index="<?php echo e($index); ?>">
                            <td><?php echo e($detail->service->service_name); ?></td>
                            <td><?php echo e($detail->quantity); ?> <?php echo e($detail->service->unit); ?></td>
                            <td>Rp <?php echo e(number_format($detail->price, 0, ',', '.')); ?></td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
            <!-- Total Harga -->
            <div class="d-flex justify-content-end align-items-center mt-4" style="max-width: 90%;">
                <div class="total-harga">
                    <div class="total--harga--text">
                        <?php
                        $existingTotalPrice = isset($transaction->details) ? $transaction->details->sum('price') : 0;
                        ?>
                        <input type="hidden" id="totalPriceInput" name="total_price" value="<?php echo e($existingTotalPrice); ?>">
                        Total Harga: <span class="text-primary" id="totalPrice">Rp <?php echo e(number_format($existingTotalPrice, 0, ',', '.')); ?></span>
                    </div>
                    <div class="transaksi--button--group">
                        <a href="<?php echo e(route('transaksi')); ?>" class="btn btn-danger me-2">Kembali</a>
                        <?php if(in_array($roleName, ['admin', 'kepala_operasional', 'kasir'])): ?>
                        <!-- <button>
                            <a href="<?php echo e(route('transaksi.print', $transaction->id)); ?>" class="btn btn-primary" target="_blank">Cetak Invoice</a>
                        </button> -->
                        <button type="submit" class="btn btn-primary" onclick="cetakInvoice()">Cetak Invoice</button>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div id="print-area" style="display: none;">
        <div class="container">
            <img src="<?php echo e(asset('assets/img/CleanLaundryLogo.png')); ?>" alt="Clean Laundry" width="100">

            <h1>Clean Laundry</h1>
            <span style="white-space: pre-line; font-size: 12px">
                Jl. Istiqomah RT01/RW08 No. 41
                Kelurahan Cipadu, Kecamatan Larangan
                Kota Tangerang, Banten
            </span>

            <div class="customer-data">
                <pre style="font-size: 10px; text-align: left; margin: 0;">
<hr>
OrderNo:   <?php echo e($transaction->order_number); ?>

Nama:      <?php echo e($transaction->customer->name); ?>

Tanggal:   <?php echo e($transaction->created_at->format('d/m/Y H:i')); ?>

Jumlah:    <?php echo e($transaction->clothes_quantity); ?> pcs
                </pre>
            </div>

            <table>
                <thead>
                    <tr>
                        <th>Layanan</th>
                        <th>Harga</th>
                        <th>Qty</th>
                        <th>Total</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $transaction->details; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $detail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($detail->service->service_name); ?></td>
                        <td>Rp <?php echo e(number_format($detail->service->price, 0, ',', '.')); ?></td>
                        <td><?php echo e($detail->quantity.$detail->service->unit); ?></td>
                        <td>Rp <?php echo e(number_format($detail->price, 0, ',', '.')); ?></td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>

            <div class="total">
                Total Harga: Rp <?php echo e(number_format($transaction->details->sum(fn($d) => $d->price), 0, ',', '.')); ?>

            </div>

        </div>

        <footer>
            <span style="white-space: pre-line; font-size: 9px">
                Terima kasih sudah memakai jasa Clean Laundry
                Semoga Anda puas dengan layanan kami!
            </span>
        </footer>
    </div>
</main>

<?php $__env->stopSection(); ?>

<style>
    .status--form--container {
        display: flex;
        justify-content: start;
    }

    .form--container {
        background-color: white;
        display: flex;
        gap: 20px;
        min-width: 350px;
    }

    .transaction-details {
        display: flex;
        flex-direction: column;
        max-width: 40%;
        width: 100%;
        font-family: Arial, sans-serif;
        font-size: 1rem;
    }

    .right-section {
        max-width: 25%;
        width: 100%;
    }

    .right-section {
        max-width: 15%;
        width: 100%;
    }

    .detail-row {
        display: flex;
        margin-bottom: 10px;
        align-items: center;
    }

    .detail-label {
        font-size: 1rem;
        font-weight: bold;
        width: 35%;
    }

    .detail-value {
        flex: 1;
        padding-left: 10px;
    }

    .status-box {
        background-color: #c0c0c0;
        color: #333;
        padding: 5px 15px;
        border-radius: 5px;
        font-weight: bold;
        text-align: center;
        display: inline-block;
        margin-left: 10px;
    }

    .mid--section {
        max-width: 50%;
        width: 100%;
    }

    .notes--container {
        margin-bottom: 20px;
    }

    .button--group {
        justify-content: flex-start;
    }

    form#updateForm {
        margin: 0 !important;
        padding: 0;
    }

    /* Responsive adjustments */
    @media (max-width: 733px) {
        .form--container {
            flex-direction: column;
        }

        .transaction-details,
        .right-section,
        .mid--section {
            max-width: 100%;
        }

        .button--group {
            justify-content: center;
        }
    }
</style>

<script>
    function enableStatusEdit() {
        document.getElementById('status-display').style.display = 'none';
        document.getElementById('status-dropdown').style.display = 'inline';
        document.getElementById('status-dropdown').disabled = false;

        document.getElementById('edit-status-button').style.display = 'none';
        document.getElementById('back-status-button').style.display = 'inline';
        document.getElementById('ok-status-button').style.display = 'inline';
    }

    function normal() {
        document.getElementById('status-display').style.display = 'inline';
        document.getElementById('status-dropdown').style.display = 'none';
        document.getElementById('status-dropdown').disabled = true;

        document.getElementById('edit-status-button').style.display = 'inline';
        document.getElementById('back-status-button').style.display = 'none';
        document.getElementById('ok-status-button').style.display = 'none';
    }

    function submitForm() {
        const statusHiddenInput = document.getElementById('status-hidden');
        const statusDropdown = document.getElementById('status-dropdown');

        if (statusHiddenInput && statusDropdown) {
            statusHiddenInput.value = statusDropdown.value;
            document.getElementById('updateForm').submit();
        } else {
            console.error("Elemen 'status-hidden' atau 'status-dropdown' tidak ditemukan.");
        }
    }

    function cetakInvoice() {
        var printContent = document.getElementById('print-area').innerHTML;
        var originalContent = document.body.innerHTML;
        document.body.innerHTML = printContent;
        window.print();
        document.body.innerHTML = originalContent;
        window.location.reload();
    }
</script>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Data\Felix\Unpam\Semester 6\KERJA PRAKTEK\code\resources\views/transaksi/view.blade.php ENDPATH**/ ?>