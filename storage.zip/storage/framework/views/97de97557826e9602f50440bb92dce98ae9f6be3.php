
<?php $__env->startSection('content'); ?>
<?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<main class="app-main">
    <div class="app-content">
        <div class="container-fluid">
            <div class="mt-5">
                <div class="card-body">
                    <div class="d-flex justify-content-between align-items-center mb-4 search-actions-container">
                        <form action="<?php echo e(route('laporan')); ?>" method="GET" id="searchForm" class="date--picker--container input-group">
                            <span class="input-group-text">
                                <i class="fa fa-calendar" aria-hidden="true"></i>
                            </span>
                            <?php
                            use Carbon\Carbon;
                            $yesterday = Carbon::yesterday()->format('d/m/Y');
                            $today = Carbon::today()->format('d/m/Y');
                            $dateRange = request('date_range', $yesterday . ' - ' . $today);
                            ?>

                            <input type="text" name="date_range" class="form-control date--picker" placeholder="Search" aria-label="Search"
                                value="<?php echo e($dateRange); ?>" />
                        </form>
                        <?php if(in_array($roleName, ['admin', 'owner'])): ?>
                        <a href="#" id="btnGeneratePDF" class="btn btn-primary">Cetak PDF</a>
                        <?php endif; ?>
                    </div>

                    <div class="table-responsive">
                        <table class="table table-bordered">
                            <thead>
                                <tr>
                                    <th>Nomor Transaksi</th>
                                    <th>Nama Pelanggan</th>
                                    <th>Tanggal Pesanan Dibuat</th>
                                    <th>Total Harga</th>
                                    <th>Status</th>
                                    <th>Tanggal Selesai</th>
                                </tr>
                            </thead>
                            <tbody id="reportTableBody">
                                <?php $__currentLoopData = $transactions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $transaction): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($transaction->order_number); ?></td>
                                    <td><?php echo e($transaction->customer->name); ?></td>
                                    <td><?php echo e($transaction->created_at->format('d/m/Y')); ?></td>
                                    <td>Rp <?php echo e(number_format($transaction->total_price, 0, ',', '.')); ?></td>
                                    <td><?php echo e($transaction->status); ?></td>
                                    <td>
                                        <?php if($transaction->status === 'Selesai'): ?>
                                        <?php echo e($transaction->updated_at->format('d/m/Y')); ?>

                                        <?php else: ?>
                                        -
                                        <?php endif; ?>
                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>

                    <div class="card-footer clearfix pagination--container">
                        <?php echo e($transactions->appends(['date_range' => request('date_range')])->links('pagination::bootstrap-4')); ?>

                    </div>
                </div>
            </div>
        </div>
    </div>
</main>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('styles'); ?>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
<?php $__env->stopPush(); ?>

<?php $__env->startPush('scripts'); ?>
<script type="text/javascript" src="https://cdn.jsdelivr.net/jquery/latest/jquery.min.js"></script>
<script type="text/javascript" src="https://cdn.jsdelivr.net/momentjs/latest/moment.min.js"></script>
<script type="text/javascript" src="https://cdn.jsdelivr.net/npm/daterangepicker/daterangepicker.min.js"></script>

<script>
    $(function() {
        $('#btnGeneratePDF').on('click', function(e) {
            e.preventDefault(); // Mencegah navigasi default
            const dateRange = $('input[name="date_range"]').val();
            if (dateRange) {
                const pdfUrl = `<?php echo e(route('report.generatePDF')); ?>?date_range=${encodeURIComponent(dateRange)}`;
                window.location.href = pdfUrl; // Navigasi ke URL dengan parameter
            } else {
                alert('Silakan pilih rentang tanggal terlebih dahulu.');
            }
        });

        $('input[name="date_range"]').daterangepicker({
            opens: 'left',
            autoUpdateInput: false,
            locale: {
                format: 'DD/MM/YYYY', // Pastikan format ini sesuai dengan yang diterima backend
                cancelLabel: 'Clear'
            }
        });

        // Event ketika pengguna mengklik "Apply"
        $('input[name="date_range"]').on('apply.daterangepicker', function(ev, picker) {
            // Set nilai input dengan format yang sesuai
            $(this).val(picker.startDate.format('DD/MM/YYYY') + ' - ' + picker.endDate.format('DD/MM/YYYY'));
            // Submit form secara otomatis
            $('#searchForm').submit();
        });

        // Event ketika pengguna mengklik "Clear"
        $('input[name="date_range"]').on('cancel.daterangepicker', function(ev, picker) {
            $(this).val('');
            $('#searchForm').submit(); // Reset data saat dibersihkan
        });
    });
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Data\Felix\Unpam\Semester 6\KERJA PRAKTEK\code\resources\views/laporan/index.blade.php ENDPATH**/ ?>