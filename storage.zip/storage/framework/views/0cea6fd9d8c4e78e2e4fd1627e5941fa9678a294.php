<form action="<?php echo e(isset($service) ? route('layanan.update', $service->id) : route('layanan.store')); ?>" method="POST">
    <?php echo csrf_field(); ?>
    <?php if(isset($service)): ?>
    <?php echo method_field('POST'); ?>
    <?php endif; ?>
    <div class="mb-3 row align-items-center">
        <label for="service_name" class="col-sm-4 col-form-label fw-semibold">Nama Layanan</label>
        <div class="col-sm-8">
            <input type="text" class="form-control" id="service_name" name="service_name" value="<?php echo e($service->service_name ?? ''); ?>" placeholder="Nama Layanan" required>
        </div>
    </div>

    <div class="mb-3 row align-items-center">
        <label for="unit" class="col-sm-4 col-form-label fw-semibold">Satuan</label>
        <div class="col-sm-8">
            <input type="tel" class="form-control" id="unit" name="unit" value="<?php echo e($service->unit ?? ''); ?>" placeholder="Satuan" required>
        </div>
    </div>

    <div class="mb-3 row align-items-center">
        <label for="price" class="col-sm-4 col-form-label fw-semibold">Harga Per Satuan</label>
                <div class="col-sm-8">
            <input type="text" class="form-control" id="price" name="price" value="<?php echo e($service->price ?? ''); ?>" placeholder="Harga Per Satuan" required>
        </div>
    </div>

    <div class="d-flex justify-content-end mt-4">
        <a href="<?php echo e(route('layanan')); ?>" class="btn btn-danger me-3" style="width: 100px;">Batal</a>
        <button type="submit" class="btn btn-primary" style="width: 100px;"><?php echo e(isset($service) ? 'Update' : 'Submit'); ?></button>
    </div>
</form><?php /**PATH /home/cleanla1/public_html/resources/views/layanan/form.blade.php ENDPATH**/ ?>