<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Transaction;
use Barryvdh\DomPDF\Facade\Pdf;
use Illuminate\Support\Facades\Redis;

class LaporanController extends Controller
{
    public function index(Request $request)
    {
        $token = $request->cookie('user_token');
        $tokenData = json_decode(base64_decode($token), true);

        $redisTokenKey = 'user_token:' . $tokenData['user_id'];
        $redisToken = Redis::get($redisTokenKey);

        if (!$redisToken || $redisToken !== $token) {
            return redirect()->route('login')->with('error', 'Session telah berakhir atau token tidak valid. Silakan login kembali.');
        }

        if (!isset($tokenData['user_id']) || empty($tokenData['user_id'])) {
            return redirect()->route('login')->with('error', 'Token tidak valid. Silakan login kembali.');
        }

        if (!isset($tokenData['role_name']) || empty($tokenData['role_name'])) {
            return redirect()->route('login')->with('error', 'Token tidak valid. Silakan login kembali.');
        }

        $roleName = $tokenData['role_name'];
        $allowedRoles = ['admin', 'owner'];

        if (!in_array($roleName, $allowedRoles)) {
            return redirect()->route('login')->with('error', 'Anda tidak memiliki akses.');
        }
        $transactions = Transaction::with('customer');

        // Filter berdasarkan rentang tanggal jika ada
        if ($request->has('date_range') && !empty($request->date_range)) {
            [$start, $end] = explode(' - ', $request->date_range);

            // Ubah format tanggal dan sesuaikan waktu
            $startDate = \Carbon\Carbon::createFromFormat('d/m/Y', $start)->startOfDay();
            $endDate = \Carbon\Carbon::createFromFormat('d/m/Y', $end)->endOfDay();

            // Terapkan filter rentang tanggal
            $transactions = $transactions->whereBetween('created_at', [$startDate, $endDate]);
        }

        // Terapkan paginasi setelah filter
        $transactions = $transactions->orderBy('created_at', 'asc')->paginate(10);

        return view('laporan.index', compact('transactions', 'roleName'));
    }

    public function generatePDF(Request $request)
    {
        $token = $request->cookie('user_token');
        $tokenData = json_decode(base64_decode($token), true);

        $redisTokenKey = 'user_token:' . $tokenData['user_id'];
        $redisToken = Redis::get($redisTokenKey);

        if (!$redisToken || $redisToken !== $token) {
            return redirect()->route('login')->with('error', 'Session telah berakhir atau token tidak valid. Silakan login kembali.');
        }

        if (!isset($tokenData['user_id']) || empty($tokenData['user_id'])) {
            return redirect()->route('login')->with('error', 'Token tidak valid. Silakan login kembali.');
        }

        if (!isset($tokenData['role_name']) || empty($tokenData['role_name'])) {
            return redirect()->route('login')->with('error', 'Token tidak valid. Silakan login kembali.');
        }

        $roleName = $tokenData['role_name'];
        $allowedRoles = ['admin', 'owner'];

        if (!in_array($roleName, $allowedRoles)) {
            return redirect()->route('login')->with('error', 'Anda tidak memiliki akses.');
        }
        // Filter transactions for PDF
        $transactions = Transaction::query();

        if ($request->has('date_range') && !empty($request->date_range)) {
            [$start, $end] = explode(' - ', $request->date_range);
            $startDate = \Carbon\Carbon::createFromFormat('d/m/Y', $start)->startOfDay();
            $endDate = \Carbon\Carbon::createFromFormat('d/m/Y', $end)->endOfDay();

            $transactions = $transactions->whereBetween('completed_at', [$startDate, $endDate]);
        }

        $transactions = $transactions->get();

        // Generate PDF
        $pdf = PDF::loadView('report_pdf', compact('transactions'));
        return $pdf->download('laporan_transaksi.pdf');
    }
}
