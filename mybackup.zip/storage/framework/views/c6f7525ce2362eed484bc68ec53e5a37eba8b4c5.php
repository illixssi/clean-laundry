<aside class="app-sidebar bg-body-secondary shadow" data-bs-theme="dark">
    <div class="sidebar-brand">
        <a href="./home" class="brand-link">
            <img src=<?php echo e(asset('assets/img/CleanLaundryLogo.png')); ?> alt="Clean Laundry Logo" class="brand-image">
        </a>
    </div>
    <div class="sidebar-wrapper">
        <nav class="sidebar--nav--container">
            <ul class="nav sidebar-menu flex-column" data-lte-toggle="treeview" role="menu" data-accordion="false">
                <div class="nav--item--container">
                    <div class="upper--nav--item">
                        <?php
                        // Mengambil token dari cookie
                        $token = request()->cookie('user_token');
                        $roleName = '';

                        if ($token) {
                        $tokenData = json_decode(base64_decode($token), true);

                        // Pengecekan token valid dan role
                        if ($tokenData && isset($tokenData['role_name'])) {
                        $roleName = $tokenData['role_name'];
                        }
                        }
                        ?>

                        
                        <li class="nav-item <?php echo e(Route::currentRouteName() == 'transaksi' ? 'active' : ''); ?>">
                            <a href="<?php echo e(route('transaksi')); ?>" class="nav-link">
                                <img src="<?php echo e(asset('assets/img/Transaksi.svg')); ?>" alt="Transaksi" width="10%" height="10%">
                                <p>Transaksi</p>
                            </a>
                        </li>

                        
                        <?php if(in_array($roleName, ['admin', 'kepala_operasional', 'kasir'])): ?>
                        <li class="nav-item <?php echo e(Route::currentRouteName() == 'pelanggan' ? 'active' : ''); ?>">
                            <a href="<?php echo e(route('pelanggan')); ?>" class="nav-link">
                                <img src="<?php echo e(asset('assets/img/Pelanggan.svg')); ?>" alt="Pelanggan" width="10%" height="10%">
                                <p>Pelanggan</p>
                            </a>
                        </li>
                        <?php endif; ?>

                        
                        <?php if(in_array($roleName, ['admin', 'kepala_operasional', 'kasir', 'owner'])): ?>
                        <li class="nav-item <?php echo e(Route::currentRouteName() == 'layanan' ? 'active' : ''); ?>">
                            <a href="<?php echo e(route('layanan')); ?>" class="nav-link">
                                <img src="<?php echo e(asset('assets/img/Layanan.svg')); ?>" alt="Layanan" width="10%" height="10%">
                                <p>Layanan</p>
                            </a>
                        </li>
                        <?php endif; ?>

                        
                        <?php if($roleName === 'admin'): ?>
                        <li class="nav-item <?php echo e(Route::currentRouteName() == 'pengguna' ? 'active' : ''); ?>">
                            <a href="<?php echo e(route('pengguna')); ?>" class="nav-link">
                                <img src="<?php echo e(asset('assets/img/Pengguna.svg')); ?>" alt="Pengguna" width="10%" height="10%">
                                <p>Pengguna</p>
                            </a>
                        </li>
                        <?php endif; ?>

                        
                        <?php if(in_array($roleName, ['admin', 'owner'])): ?>
                        <li class="nav-item <?php echo e(Route::currentRouteName() == 'laporan' ? 'active' : ''); ?>">
                            <a href="<?php echo e(route('laporan')); ?>" class="nav-link">
                                <img src="<?php echo e(asset('assets/img/Laporan.svg')); ?>" alt="Laporan" width="10%" height="10%">
                                <p>Laporan</p>
                            </a>
                        </li>
                        <?php endif; ?>
                    </div>
                    <div class="bottom--nav--item">
                        <li class="nav-item">
                            <a href="<?php echo e(route('password.change')); ?>" class="nav-link">
                                <img src="<?php echo e(asset('assets/img/UbahKataSandi.svg')); ?>" alt="UbahKataSandi" width="10%" height="10%">
                                <p>Ubah Kata Sandi</p>
                            </a>
                        </li>
                        <li class="nav-item">
                            <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                                <?php echo csrf_field(); ?>
                            </form>
                            <a href="#" class="nav-link" onclick="event.preventDefault(); document.getElementById('logout-form').submit();">
                                <img src="<?php echo e(asset('assets/img/Keluar.svg')); ?>" alt="Keluar" width="10%" height="10%">
                                <p>Keluar</p>
                            </a>
                        </li>
                    </div>
                </div>
            </ul>
        </nav>
    </div>
</aside><?php /**PATH /home/cleanla1/public_html/resources/views/layouts/sidebar.blade.php ENDPATH**/ ?>