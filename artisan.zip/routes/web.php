<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\AuthController;
use Illuminate\Support\Facades\Hash;

Route::get('/login', function () {
    return view('auth.login');
})->name('login');

Route::post('/login', [AuthController::class, 'login'])->name('login.submit');

Route::get('/', function () {
    return view('welcome');
});

Route::get('/transaksi', function () {
    return view('transaksi');
})->name('transaksi');

Route::get('/pelanggan', function () {
    return view('pelanggan');
})->name('pelanggan');

Route::get('/layanan', function () {
    return view('layanan');
})->name('layanan');

Route::get('/pengguna', function () {
    return view('pengguna');
})->name('pengguna');

Route::get('/laporan', function () {
    return view('laporan');
})->name('laporan');

Route::get('/makePassword', function () {
    $password = 'admin'; // Ganti dengan password yang ingin di-hash
    $hashedPassword = Hash::make($password); // Menggunakan Hash::make untuk membuat bcrypt hash

    return 'Hashed Password: ' . $hashedPassword;
});