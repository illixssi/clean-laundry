@extends('layouts.app')

@section('content')
<!-- Memanggil Header -->
@include('layouts.header')

<!-- Memanggil Sidebar -->
@include('layouts.sidebar')

<!-- Content di sini -->
<main class="app-main">
    <!--begin::App Content Header-->
    <div class="app-content">
        <!--begin::Container-->
        <div class="container-fluid">
            <!--begin::Row-->
            <div class="mt-5">
                <div class="card-body">
                    <div class="d-flex justify-content-between align-items-center mb-4">
                        <!-- Tombol Tambah Transaksi -->
                        <button class="button--primary">Tambah Transaksi</button>

                        <!-- Kolom Pencarian -->
                        <div class="search-container">
                            <input type="text" class="form-control" placeholder="Search" aria-label="Search">
                        </div>
                    </div>

                    <!-- Tabel Data Transaksi -->
                    <table class="table table-bordered">
                        <thead>
                            <tr>
                                <th>Nomor Order</th>
                                <th>Nama Pelanggan</th>
                                <th>Tanggal Pesanan Dibuat</th>
                                <th>Total Harga</th>
                                <th>Status</th>
                                <th>Aksi</th>
                            </tr>
                        </thead>
                        <tbody>
                            @for ($i = 1; $i <= 10; $i++)
                                <tr class="align-middle">
                                    <td>Or12314</td>
                                    <td>Liana</td>
                                    <td>2024-08-08 14:02</td>
                                    <td>Rp 200.000</td>
                                    <td>Dalam Proses</td>
                                    <td>
                                        <button class="btn btn-sm"><img src="{{ asset('assets/img/eye.svg') }}" alt="Lihat"
                                                width="60%" height="60%"></button>
                                        <button class=" btn btn-sm"><img src="{{ asset('assets/img/edit.svg') }}"
                                                alt="Lihat" width="60%" height="60%"></button>
                                        <button class="btn btn-sm"><img src="{{ asset('assets/img/trash.svg') }}"
                                                alt="Lihat" width="60%" height="60%"></button>
                                    </td>
                                </tr>
                            @endfor
                        </tbody>
                    </table>

                    <!-- Pagination -->
                    <div class="card-footer clearfix">
                        <ul class="pagination pagination-sm m-0 float-end">
                            <li class="page-item">
                                <a class="page-link" href="#">&laquo;</a>
                            </li>
                            <li class="page-item">
                                <a class="page-link" href="#">1</a>
                            </li>
                            <li class="page-item">
                                <a class="page-link" href="#">2</a>
                            </li>
                            <li class="page-item">
                                <a class="page-link" href="#">3</a>
                            </li>
                            <li class="page-item">
                                <a class="page-link" href="#">&raquo;</a>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
        <!--end::Container-->
    </div>
    <!--end::App Content-->
</main>
@endsection