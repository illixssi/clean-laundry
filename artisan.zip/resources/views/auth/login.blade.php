@extends('layouts.app')

@section('title', 'Login')

@section('content')
<div class="d-flex justify-content-center align-items-center" style="height: 100vh; width: 100vw;">
    <div class="login-box text-center" style="max-width: 400px; width: 100%;">
        <div class="login-logo mb-5">
            <img src="{{ asset('assets/img/CleanLaundryLogo.png') }}" alt="Clean Laundry Logo" style="width: 200px;">
        </div>
        <div class="card p-4">
            <div class="card-body login-card-body">
                <p class="login-box-msg">Silahkan login untuk melanjutkan</p>
                <form action="{{ route('login.submit') }}" method="post">
                    @csrf
                    <div class="input-group mb-3">
                        <input type="text" name="username" class="form-control" placeholder="Username" required>
                    </div>
                    <div class="input-group mb-3 input--password--container">
                        <input type="password" id="password" name="password" class="form-control" placeholder="Password" required>
                        <div class="password--toggle">
                            <span class="">
                                <img id="toggle-icon" src="{{ asset('assets/img/Eye.svg') }}" alt="Show Password" style="width: 1.8rem; cursor: pointer;" onclick="togglePassword()">
                            </span>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-12">
                            <button type="submit" class="btn btn-primary btn-block">Masuk</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<script>
    function togglePassword() {
        var passwordInput = document.getElementById("password");
        var toggleIcon = document.getElementById("toggle-icon");
        if (passwordInput.type === "password") {
            passwordInput.type = "text";
            toggleIcon.src = "{{ asset('assets/img/Hide.svg') }}"; // Mengganti ikon jadi mata tertutup
        } else {
            passwordInput.type = "password";
            toggleIcon.src = "{{ asset('assets/img/Eye.svg') }}"; // Mengganti ikon jadi mata terbuka
        }
    }
</script>
@endsection
