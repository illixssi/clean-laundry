<aside class="app-sidebar bg-body-secondary shadow" data-bs-theme="dark">
    <div class="sidebar-brand">
        <a href="./home" class="brand-link">
            <img src="../assets/img/CleanLaundryLogo.png" alt="Clean Laundry Logo" class="brand-image">
        </a>
    </div>
    <div class="sidebar-wrapper">
        <nav class="sidebar--nav--container">
            <ul class="nav sidebar-menu flex-column" data-lte-toggle="treeview" role="menu" data-accordion="false">
                <div class="nav--item--container">
                    <div class="upper--nav--item">
                        <li class="nav-item {{ Route::currentRouteName() == 'transaksi' ? 'active' : '' }}">
                            <a href="{{ route('transaksi') }}" class="nav-link">
                                <i class="nav-icon bi bi-palette"></i>
                                <p>Transaksi</p>
                            </a>
                        </li>
                        <li class="nav-item {{ Route::currentRouteName() == 'pelanggan' ? 'active' : '' }}">
                            <a href="{{ route('pelanggan') }}" class="nav-link">
                                <i class="nav-icon bi bi-palette"></i>
                                <p>Pelanggan</p>
                            </a>
                        </li>
                        <li class="nav-item {{ Route::currentRouteName() == 'layanan' ? 'active' : '' }}">
                            <a href="{{ route('layanan') }}" class="nav-link">
                                <i class="nav-icon bi bi-palette"></i>
                                <p>Layanan</p>
                            </a>
                        </li>
                        <li class="nav-item {{ Route::currentRouteName() == 'pengguna' ? 'active' : '' }}">
                            <a href="{{ route('pengguna') }}" class="nav-link">
                                <i class="nav-icon bi bi-palette"></i>
                                <p>Pengguna</p>
                            </a>
                        </li>
                        <li class="nav-item {{ Route::currentRouteName() == 'laporan' ? 'active' : '' }}">
                            <a href="{{ route('laporan') }}" class="nav-link">
                                <i class="nav-icon bi bi-palette"></i>
                                <p>Laporan</p>
                            </a>
                        </li>
                    </div>
                    <div class="bottom--nav--item">
                        <li class="nav-item">
                            <a href="./transaksi" class="nav-link">
                                <i class="nav-icon bi bi-palette"></i>
                                <p>Ubah Kata Sandi</p>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="./transaksi" class="nav-link">
                                <i class="nav-icon bi bi-palette"></i>
                                <p>Keluar</p>
                            </a>
                        </li>
                    </div>
                </div>
            </ul>
        </nav>
    </div>
</aside>