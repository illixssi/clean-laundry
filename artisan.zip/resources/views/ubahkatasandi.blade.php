<!-- resources/views/home.blade.php -->
@extends('layouts.app')

@section('content')
<!-- Memanggil Header -->
@include('layouts.header')

<!-- Memanggil Sidebar -->
@include('layouts.sidebar')

<!-- Content di sini -->
<main class="app-main">
    <!--begin::App Content Header-->
    <div class="container">
        <h1>Ubah Kata Sandi</h1>
        <!-- Konten lain di sini -->
    </div>
</main>
@endsection