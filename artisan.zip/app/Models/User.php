<?php

namespace App\Models;

use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;

class User extends Authenticatable
{
    use Notifiable;

    // Arahkan ke tabel user_accounts
    protected $table = 'user_accounts';

    // Kolom yang dapat diisi (fillable)
    protected $fillable = [
        'username',
        'password',
    ];

    // Jika kamu menggunakan kolom id yang berbeda, tambahkan:
    // protected $primaryKey = 'id';
}
