<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Redis;
use Illuminate\Support\Str;

class AuthController extends Controller
{
    public function login(Request $request)
    {
        $credentials = $request->only('username', 'password');

        if (Auth::attempt($credentials)) {
            // Generate token
            $token = Str::random(60);

            // Save token to Redis with 30 minutes expiration
            // Redis::setex('user_token:' . Auth::id(), 1800, $token);

            return redirect()->route('transaksi')->with('success', 'Login berhasil!');
        } else {
            return back()->withErrors([
                'message' => 'Login Gagal! Username atau kata sandi salah'
            ]);

            // $token = Redis::get('user_token:' . Auth::id());

        }
    }
}
